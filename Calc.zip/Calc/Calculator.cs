﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Calc.Configurations;
using Calc.Expressions;

namespace Calc
{
    class Calculator
    {
        private int accuracy;
        private readonly IStorage _storage;
        private string historylist;
        public Calculator(int accuracy, IStorage storage)
        {
            this.accuracy = accuracy;
            _storage = storage;
        }

        public void AddExpression(double arg1, double arg2, char operation)
        {
            var operatorFactory = new OperatorFactory();
            IOperator @operator = operatorFactory.CreateOperator(operation);

            Expression expr = new Expression(arg1, arg2, @operator);
            
            AddToHistoryList(expr);
            System.Console.WriteLine(expr.ToString());
        }

        public void AddToHistoryList(Expression e){
            historylist += e.ToString();
            historylist += '\n';
        }
        public void ShowHistory()
        {
            if (String.IsNullOrEmpty(historylist))
            {
                System.Console.WriteLine("\nHistory is empty. Nothing to show");
                return;
            }
            System.Console.WriteLine("\n" + historylist);
        }

        public List<Expression> GetHistory()
        {
            throw new NotImplementedException();
        }

        public void Save()
        {
            _storage.Save(new List<Expression>());
        }

        public void WriteToFile()
        {
            if (String.IsNullOrEmpty(historylist))
            {
                System.Console.WriteLine("\nHistory is empty. Nothing is saved to a file");
                return;
            }
            char[] delimiters = {'\n'};
            string[] lines = historylist.Split(delimiters);
            try
            {
                string filepath = Config.GetSaveString();
                System.IO.StreamWriter writer = new System.IO.StreamWriter(@filepath, true);
                foreach (string line in lines)
                {
                    writer.WriteLine(line);
                }
                writer.Close();
                System.Console.WriteLine("\nResult saved to a file");
            }
            catch (Exception e)
            {
                System.Console.WriteLine(e.ToString());
            }
        }
    }
}
