using System.Collections.Generic;
using Calc.Expressions;

namespace Calc
{
    public class CloudStorage : IStorage
    {
        public void Save(IEnumerable<Expression> expressions)
        {
            throw new System.NotImplementedException();
        }
    }
}