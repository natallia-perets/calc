﻿namespace Calc
{
    public interface IOperator
    {
        double Apply(double a, double b);
    }
}