﻿using System;

namespace Calc
{
    public class OperatorFactory
    {
        public IOperator CreateOperator(char o)
        {
            throw new NotImplementedException();
        }
    }
}