﻿using System.Collections.Generic;
using Calc.Expressions;

namespace Calc
{
    public interface IStorage
    {
        void Save(IEnumerable<Expression> expressions);
    }
}