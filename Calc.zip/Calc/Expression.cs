﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Calc.Configurations;

namespace Calc.Expressions
{

    public class Expression
    {

        private class MyClass
        {
            
 
        }

        private readonly double _arg1;
        private readonly double _arg2;
        private readonly IOperator _o;
        private readonly double _result;

        public Expression(double arg1, double arg2, IOperator o)
        {
            _arg1 = arg1;
            _arg2 = arg2;
            _o = o;
        }

        public double Calculate()
        {
            double result = _o.Apply(_arg1, _arg2);

            return result;
        }


/*
        private void Add()
        {
            result = Math.Round(arg1 + arg2, precision);
        }
        private void Subtract()
        {
            result = Math.Round(arg1 - arg2, precision);
        }
        private void Divide()
        {
            result = Math.Round(arg1 / arg2, precision);
        }
        private void Multiply()
        {
            result = Math.Round(arg1 * arg2, precision);
        }*/
        public override string ToString()
        {
            return string.Format("{0} {2} {1} = {3}", _arg1, _arg2, _o, _result);
        } 
    }
}
